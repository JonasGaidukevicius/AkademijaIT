package lt.vtvpmc.ems.akademijait.jonas;

public class KitaKlase {
}

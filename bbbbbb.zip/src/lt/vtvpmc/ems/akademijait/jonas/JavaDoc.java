package lt.vtvpmc.ems.akademijait.jonas;

/**
 * @author Jonas Gaidukevičius
 * @version 2.5.8
 */

public class JavaDoc {
    /**
     * name - this is the name of a person
     * age - this is the age of a person
     */

    String name;
    int age;


    /**
     *
     * @param name
     * @param age
     */
    public JavaDoc(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public static void main(String[] args) {
        System.out.println("ffffffffffffffff" + "fgggggggggggggggggggggggg"
                + "tttttttttttttttttttttttt" + "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");
    }


    /**
     *
     * @param a
     * @param sss
     */
    public static void say(String a, int sss){
        //TODO

    }


}
